/**
 * Appcelerator Titanium Mobile
 * This is a generated file -- DO NOT HAND EDIT
 */
import org.appcelerator.titanium.api.ITitaniumUserData;
import org.appcelerator.titanium.api.ITitaniumProperties;

public final class AppUserData implements ITitaniumUserData 
{
	public AppUserData()
	{
	}
	public void load (ITitaniumProperties properties)
	{
		__MODULE_BODY__
	}
}
